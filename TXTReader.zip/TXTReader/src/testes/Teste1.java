package testes;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class Teste1 {
	public static void main(String[] args) {
		try {

			File arquivos[];
			String linha = new String();
			String dir = "C:\\Users\\gprodrigues\\Desktop\\amostra";
			File arq = new File(dir);
			// this strin bellow is the name of the new csv file
			String namecsv = "\\TesteFiltrados.csv";
			FileOutputStream write = new FileOutputStream(dir + namecsv);
			PrintWriter pr = new PrintWriter(write);
			arquivos = arq.listFiles();
			// each position fo this vector called "campo" is the nome of one collum for the new file 
			String[] campo = { "name1", "name2" };
			// this "|" add is for help split the coluns when u tranform the csv file for excel with is my intention afterward
			pr.println(campo[0] + "|" + campo[1] + "|");
			int contaarq = 1;
			for (int u = 0; u < arquivos.length; u++) {
				int contadorlinha = 0;
				if (arquivos[u].exists()) {
					FileReader leitor = new FileReader(arquivos[u]);
					BufferedReader br = new BufferedReader(leitor);
					while (true) {
						linha = br.readLine();
						if (linha == null) {
							break;
						}
						linha = linha.replace("|", ";");
						String[] vetor = linha.split(";");
//						filtrador=filtrador.replace(" ", "");
						if (contadorlinha == 0) {
						} else {
							String filtrador, filtrador2;
							if (vetor[5] == null) {
								filtrador = " ";
							} else {
								filtrador = String.valueOf(vetor[5]);
							}
							filtrador2 = String.valueOf(vetor[26]);
							String comparador = "1";
							String comparador2_1 = "600", comparador2_2 = "610", comparador2_3 = "611",
									comparador2_4 = "800", comparador2_5 = "902";

							if (!(filtrador.equalsIgnoreCase(comparador))
									&& (!filtrador2.equalsIgnoreCase(comparador2_1))
									&& (!filtrador2.equalsIgnoreCase(comparador2_2))
									&& (!filtrador2.equalsIgnoreCase(comparador2_3))
									&& (!filtrador2.equalsIgnoreCase(comparador2_4))
									&& (!filtrador2.equalsIgnoreCase(comparador2_5))) {
								String valorvetor = vetor[28];
								String saldo = valorvetor.replace(".", ",");
								pr.println(vetor[0] + "|" + vetor[3] + "|" + vetor[4] + "|" + vetor[5] + "|" + vetor[9]
										+ "|" + vetor[12] + "|" + vetor[13] + "|" + vetor[14] + "|" + vetor[20] + "|"
										+ vetor[22] + "|" + vetor[25] + "|" + vetor[27] + "|" + saldo + "|" + vetor[29]
										+ "|" + vetor[32] + "|" + vetor[33] + "|" + vetor[34]);

							} else {
							}
						}
						contadorlinha++;
					}
					br.close();
				} else {
					System.out.println("Arquivo n�o encontrado");
				}
				System.out.println("Arquivo " + contaarq + " Registrado com suceso!!");
				contaarq++;
			}
			pr.close();
			write.close();
		} catch (IOException e) {
			System.out.println("Erro: " + e);
		}
	}
}
